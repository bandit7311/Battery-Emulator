$Format:%H$
